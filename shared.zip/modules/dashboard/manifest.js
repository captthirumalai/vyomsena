export const manifest = {
  path: '/dashboard',
  name: 'Dashboard',
  title: 'Dashboard Overview',
  icon: 'dashboard',
  order: 10,
  showInMenu: true,
  permissions: ['operations'],
  breadcrumbs: ['Home', 'Dashboard'],
  html: 'modules/dashboard/dashboard.html',
  js: 'modules/dashboard/dashboard.js',
  css: 'modules/dashboard/dashboard.css'
};
